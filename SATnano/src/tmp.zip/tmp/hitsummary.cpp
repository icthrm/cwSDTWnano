#include "opts.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <proc/io.h>
#include "util/exception.h"
#include <dirent.h>
#include <iomanip>

int ReadFileList(char* basePath, std::vector<std::string>& filelist){
	DIR *dir;
	struct dirent *ptr;
	char base[1000];
	
	if ((dir=opendir(basePath)) == NULL){
		perror("Open dir error...");
		exit(1);
	}
	
	while ((ptr=readdir(dir)) != NULL){
		if(strcmp(ptr->d_name,".")==0 || strcmp(ptr->d_name,"..")==0){    ///current dir OR parrent dir
			continue;
		}
		else if(ptr->d_type == 8){    ///file
			filelist.push_back(std::string(ptr->d_name));
		}
		else if(ptr->d_type == 10){    ///link file
			filelist.push_back(std::string(ptr->d_name));
		}
// 		else if(ptr->d_type == 4)    ///dir
// 		{
// 			memset(base,'\0',sizeof(base));
// 			strcpy(base,basePath);
// 			strcat(base,"/");
// 			strcat(base,ptr->d_name);
// 			readFileList(base);
// 		}
	}
	closedir(dir);
	return 1;
}

bool ReadReport(const char* filename, int& hit, int& nonhit){
	std::ifstream in(filename);
    if(!in.good()) {
        return false;
    }
	
    std::string buf;
    if(!getline(in, buf)){
        return false;
    }
    
    int hitmark;
    while(in.good()){
		char item;
		double tmp;
		std::string kmer;
		in>>hitmark>>item>>tmp>>tmp>>item>>tmp>>tmp>>tmp>>item>>tmp>>tmp;
        
        if(in.fail()){
            break;
        }
        if(hitmark){
			hit++;
        }
        else{
			nonhit++;
        }
    }
    
    in.close();
	
    return true;
}

int main(int argc, char **argv)
{
	struct options opts;
	if(GetOpts(argc, argv, &opts) < 0){
		return 0;
	}
	
	EX_TRACE("Read the DIR of reports.\n");
	
	std::vector<std::string> filelist;
	ReadFileList(opts.input, filelist);
	
	int hit = 0, nonhit = 0;
	for(int i = 0; i < filelist.size(); i++){
		std::cout<<".";
		std::cout.flush();
		ReadReport((std::string(opts.input)+"/"+filelist[i]).c_str(), hit, nonhit);
	}
	std::cout<<std::endl;
	
	std::ofstream of(opts.output);
	
	of<<std::setw(15)<<"#hit"<<" | "<<std::setw(15)<<"nonhit"<<std::endl;
	of<<std::setw(15)<<hit<<std::setw(15)<<nonhit<<std::endl;
	of.close();
	
	return 0;
}

