#include "opts.h"
#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "proc/proc.h"
#include "util/exception.h"
#include "6mer/6mer_index.h"
#include "wavelib.h"
#include <malloc.h>
#include <cmath>
#include <sstream>
#include <iomanip>

#include <cassert>
extern "C" {
#include <getopt.h>
}
#include "util/exception.h"

struct rqopt {
    char input[255];
    char peer[255];
	char reference[255];
	char output[255];
	float scale_diff;
	int length;
};

inline int GetOpts(int argc, char **argv, rqopt* opts_) {

    static struct option longopts[] = {
        { "input",     required_argument,      NULL,    			  'i' },
        { "peer",    	     required_argument,      NULL,      	'p' },
        { "output",      	required_argument,      NULL,              'o' },
        { "reference",      required_argument,      NULL,              'r' },
		{ "scale",      required_argument,      NULL,              's' },
		{ "length",      required_argument,      NULL,              'l' },
        { NULL,              0,                      NULL,               0 }
    };

    int ch;
    while((ch = getopt_long(argc, argv, "i:p:o:r:s:l:", longopts, NULL))!= -1) {
        switch(ch) {

        case '?':
            EX_TRACE("Invalid option '%s'.", argv[optind-1]);
            return -1;

        case ':':
            EX_TRACE("Missing option argument for '%s'.", argv[optind-1]);
            return -1;

        case 'i':
        {
            std::istringstream iss(optarg);
            iss >> opts_->input;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;
		
        case 'p':
        {
            std::istringstream iss(optarg);
            iss >> opts_->peer;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;

        case 'o':
        {
            std::istringstream iss(optarg);
            iss >> opts_->output;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;
		
        case 'r':
        {
            std::istringstream iss(optarg);
            iss >> opts_->reference;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;	
		
		case 's':
        {
            std::istringstream iss(optarg);
            iss >> opts_->scale_diff;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;	

		case 'l':
        {
            std::istringstream iss(optarg);
            iss >> opts_->length;
            if(iss.fail())
                EX_TRACE("Invalid argument '%s'.", optarg);
        }
        break;
        case 0:
            break;

        default:
            assert(false);
        }
    }
    return 1;
}

using namespace std;

void WriteSequenceAlignment(const char* output, const vector<char>& genomes, const std::vector<double>& reference_orig, const std::vector<double>& peer_orig, 
							const std::vector<double>& reference, const std::vector<double>& peer, vector<pair<int,int> >& alignment)
{
	std::ofstream o(output);
	
	double diff, avgdiff = 0;
	
	for(int i = 0; i < alignment.size() && alignment[i].first+6 < genomes.size(); i++){
		o<<setw(10)<<alignment[i].first<<" "<<setw(9)<<alignment[i].second<<" | "
		<<setw(15)<<reference_orig[alignment[i].first]<<" "<<setw(15)<<peer_orig[alignment[i].second]<<" | "
		<<setw(15)<<reference[alignment[i].first]<<" "<<setw(15)<<peer[alignment[i].second]<<"          diff:"
		<<setw(15)<<(diff = std::fabs(reference[alignment[i].first]-peer[alignment[i].second]))<<"          "; avgdiff += diff;
		for(int j = 0; j < 6 && j+alignment[i].first < genomes.size(); j++){
			o<<genomes.at(alignment[i].first+j);
		}
		o<<std::endl;
	}
}

void WriteFundamentalAlignment(const char* output, double ndist, const vector<char>& genomes, const std::vector<double>& reference_orig, 
							   const std::vector<double>& peer_orig, vector<pair<int,int> >& alignment)
{
	std::ofstream o(output);
	
	o<<ndist<<std::endl;
	o<<setw(10)<<"#query_idx"<<setw(15)<<"signal_idx"<<" | "
		<<setw(15)<<"query_value"<<" "<<setw(15)<<"signal_value"<<setw(15)<<"6-mer"<<std::endl;
	
	for(int i = 0; i < alignment.size() && alignment[i].first+6 < genomes.size(); i++){
		o<<setw(10)<<alignment[i].first<<setw(15)<<alignment[i].second<<" | "
		<<setw(15)<<reference_orig[alignment[i].first]<<" "<<setw(15)<<peer_orig[alignment[i].second]<<setw(10);
		for(int j = 0; j < 6 && j+alignment[i].first < genomes.size(); j++){
			o<<genomes.at(alignment[i].first+j);
		}
		o<<std::endl;
	}
}

bool ReadFundamentalAlignment(const char* reference, vector<pair<int,int> >& alignment)
{
	std::ifstream in(reference);
    if(!in.good()) {
        return false;
    }
    
    double ndist;
    
	in>>ndist;
    //-> skip first header
	
    std::string buf;
	getline(in, buf);
    if(!getline(in, buf)){
        return false;
    }
    
    while(in.good()){
		std::pair<int, int> match;
		char item;
		double tmp;
		std::string kmer;
		in>>match.first>>match.second>>item>>tmp>>tmp>>kmer;
        
        if(in.fail()){
            break;
        }
        alignment.push_back(match);
    }
    
    in.close();
	
    return true;
}

int main(int argc, char **argv)
{
	struct rqopt opts;
	opts.scale_diff = 8;
	opts.length = 128;
	
	if(GetOpts(argc, argv, &opts) < 0){
		EX_TRACE("**WRONG INPUT!**\n")
		return 0;
	}
		
	std::vector<char> genomes;
	std::vector<double> reference;	//reference: genome
	std::vector<double> peer;		//peer: nanopore signal
	
	int start;
	std::vector<char> subgene;
	EX_TIME_BEGIN("\nTransform genomes to signal sequence...");
	
	if(strcmp(g::io::GetFileExtension(opts.input).c_str(), "fast5") == 0){
		if(g::io::ReadFast5ATCG(opts.input, genomes))
			EX_TRACE("%ld genomes are readed.\n", genomes.size());
	}
	else if(g::io::ReadATCG(opts.input, genomes)){
		EX_TRACE("%ld genomes are readed.\n", genomes.size());
	}
	else{
		EX_TRACE("Cannot open %s.\n", opts.input);
		return -1;
	}
	
	if(strcmp(g::io::GetFileExtension(opts.peer).c_str(), "fast5") == 0){
		if(!g::io::ReadFast5SignalSequence(opts.peer, peer)){
			EX_TRACE("Cannot open %s.\n", opts.peer);
			return -1;
		}
	}
	else if(!g::io::ReadSignalSequence(opts.peer, peer)){
		EX_TRACE("Cannot open %s.\n", opts.peer);
		return -1;
	}
	else{
		EX_TRACE("%ld signals are readed.\n", peer.size());
	}
	
	g::proc::ZScoreNormalize(peer);
	
	EX_TIME_END("Transform genomes to signal sequence...");
	EX_TIME_BEGIN("Short reads inquiry...")
	
	std::ofstream ostat;
	ostat.open((std::string(opts.output)+".1").c_str());
	ostat<<setw(15)<<"#consistent"<<" | "<<setw(15)<<"query_length"<<setw(15)<<"genome_begin"<<" | "
		<<setw(15)<<"genome_end"<<" "<<setw(15)<<"query_sig_idx1"<<setw(15)<<"query_sig_idx2"<<" | "
		<<setw(15)<<"wali_sig_idx1"<<" "<<setw(15)<<"wali_sig_idx2"<<std::endl;
	
	srand(time(NULL));
	
	for(int i = 0; i < 10; i++){
		start = (128+rand())%(genomes.size()-128);
		subgene.resize(opts.length);
		memcpy(&(subgene[0]), &(genomes[start]), sizeof(char)*opts.length);
		
		reference.clear();
		g::io::Genomes2SignalSequence(subgene, reference, 1);
		
	// 	std::vector<double> reference_orig(reference), peer_orig(peer);
		
		g::proc::ZScoreNormalize(reference);
		
		std::vector<std::pair<int,int> > alignment;
		
		double ndist;
		EX_TIME_BEGIN("Direct inquiry...")
		ndist = g::proc::DirectInquiry(reference, peer, alignment, opts.scale_diff, 50, 1, true);
		EX_TRACE("Feedback-->[%d : %d] in the raw signal\n", alignment[0].second, alignment[alignment.size()-1].second)
		EX_TIME_END("Direct inquiry...")
		
		for(int i = 0; i < alignment.size(); i++){
			alignment[i].first += start;
		}
		
	// 	WriteFundamentalAlignment(opts.output, ndist, genomes, reference_orig, peer_orig, alignment);
			
		std::pair<int, int> wfront, wback;
		
		std::vector<std::pair<int,int> > wholealign;
		ReadFundamentalAlignment(opts.reference, wholealign);
		for(int i = 0; i < wholealign.size(); i++){
			if(wholealign[i].first == alignment.front().first){
				wfront = wholealign[i];
	// 			std::cout<<wholealign[i].first<<" "<<wholealign[i].second<<std::endl;;
			}
			if(wholealign[i].first == alignment.back().first){
				wback = wholealign[i];
	// 			std::cout<<wholealign[i].first<<" "<<wholealign[i].second<<std::endl;;
				break;
			}
		}
		
		bool consistent = true;	
		if(alignment.front().second > wback.second || alignment.back().second < wfront.second){
			consistent = false;
		}
			
		ostat<<setw(15)<<consistent<<" | "<<setw(15)<<opts.length<<setw(15)<<alignment.front().first<<" | "
			<<setw(15)<<alignment.back().first<<" "<<setw(15)<<alignment.front().second<<setw(15)<<alignment.back().second<<" | "
			<<setw(15)<<wfront.second<<" "<<setw(15)<<wback.second<<std::endl;	
	}
	
	EX_TIME_END("Short reads inquiry...")
	
	return 0;
}

