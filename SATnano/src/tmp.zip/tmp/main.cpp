#include "opts.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <proc/io.h>
#include "util/exception.h"
#include "6mer/6mer_index.h"
#include <map>

int main(int argc, char **argv)
{
	struct options opts;
	if(GetOpts(argc, argv, &opts) < 0){
		return 0;
	}
	
	EX_TRACE("Read the input file...\n");
	
	std::vector<char> genomes;
	
	g::io::ReadATCG(opts.input, genomes);
	EX_TRACE("%ld genomes are readed.\n", genomes.size());
	
	EX_TRACE("Counting the homopolymers...\n");
	
	std::map<int, long> hash;
	hash.insert(std::make_pair('A'*10000+1, 0));
	hash.insert(std::make_pair('T'*10000+1, 0));
	hash.insert(std::make_pair('C'*10000+1, 0));
	hash.insert(std::make_pair('G'*10000+1, 0));
	
	char flag = 0;
	bool homo = false;
	long count = 0;
	
	for(long i = 1; i < genomes.size(); i++){
		if(genomes[i] != 'A' && genomes[i] != 'T' && genomes[i] != 'C' && genomes[i] != 'G'){
			continue;
		}
		
		if(!homo){
			if(genomes[i] == genomes[i-1]){
				flag = genomes[i];
				homo = true;
				count = 2;
			}
			else{
				hash.find(genomes[i]*10000+1)->second += 1;
			}
		}
		else{
			if(genomes[i] == genomes[i-1]){
				count++;
			}
			else{
				std::map<int, long>::iterator it = hash.find(flag*10000+count);
				if(it != hash.end()){
					it->second++;
				}
				else{
					hash.insert(std::make_pair(flag*10000+count, 1));
				}
				homo = false;
			}
		}
	}
	
	std::ofstream o, o2;
	o.open(opts.output);
	o2.open("stats.data");
	
	for(std::map<int, long>::iterator i = hash.begin(); i != hash.end(); i++){
		o<<"["<<char(i->first/10000)<<","<<i->first%10000<<"]\t"<<i->second<<std::endl;
		o2<<"["<<char(i->first/10000)<<","<<i->first%10000<<"]\t"<<i->second<<std::endl;
	}
	o.close();
	o2.close();
	
	return 0;
}

