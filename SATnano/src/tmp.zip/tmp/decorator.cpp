#include "opts.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <proc/io.h>
#include "util/exception.h"
#include "6mer/6mer_index.h"
#include <vector>
#include <time.h>

#define ML  35
	
static long ap[ML], tp[ML], cp[ML], gp[ML];

int randomPolymer(char n)
{
	long* distribution;
	switch(n){
	case 'A':
		distribution = ap;
		break;
	case 'T':
		distribution = tp;
		break;
	case 'C':
		distribution = cp;
		break;
	case 'G':
		distribution = gp;
		break;
	
	}
	
	while(true){
		long percent = random()%distribution[1];
		int num = random()%ML;
		if(percent < distribution[num]){
			return num;
		}
	}
}

int main(int argc, char **argv)
{
	struct options opts;
	if(GetOpts(argc, argv, &opts) < 0){
		return 0;
	}
	
	EX_TRACE("Read the input file...\n");
	
	srand(time(NULL));
	
	std::vector<char> genomes;
	std::vector<char> output;
	
	g::io::ReadATCG(opts.input, genomes);
	EX_TRACE("%ld genomes are readed.\n", genomes.size());
	
	output.reserve(genomes.size()*1.5);
	
	EX_TRACE("Counting the homopolymers...\n");
	
	std::ifstream stat;
	stat.open("stats.data");
	
	char ch;
	char flag;
	int len;
	long num;
	
	memset(ap, 0, sizeof(long)*ML);
	memset(tp, 0, sizeof(long)*ML);
	memset(cp, 0, sizeof(long)*ML);
	memset(gp, 0, sizeof(long)*ML);
	
	while(stat.good()){
		stat>>ch>>flag>>ch>>num>>ch>>len;
		if(flag == 'A' && num < ML){
			ap[num] = len;
		}
		if(flag == 'T' && num < ML){
			tp[num] = len;
		}
		if(flag == 'C' && num < ML){
			cp[num] = len;
		}
		if(flag == 'G' && num < ML){
			gp[num] = len;
		}
	}
	
	for(long i = 0; i < genomes.size(); i++){
		int len = randomPolymer(genomes[i]);
		for(int k = 0; k < len; k++){
			output.push_back(genomes[i]);
		}
	}
	
	std::ofstream o;
	o.open(opts.output);
	o<<">simulated homopolymer"<<std::endl;
	
	for(long i = 0; i < output.size(); i++){
		o<<output[i];
	}
	o<<std::endl;
	o.close();
	
	return 0;
}

